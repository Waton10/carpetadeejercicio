fun main() {
    val fizzBuzz = FizzBuzz()
    fizzBuzz.printRange(1, 100)
}

interface FizzBuzzBehavior {
    fun evaluate(number: Int): String
    fun printRange(start: Int, end: Int)
}

class FizzBuzz : FizzBuzzBehavior {
    override fun evaluate(number: Int): String {
        return when {
            number % 15 == 0 -> "FizzBuzz"
            number % 3 == 0 -> "Fizz"
            number % 5 == 0 -> "Buzz"
            else -> number.toString()
        }
    }

    override fun printRange(start: Int, end: Int) {
        for (i in start..end step 10) {
            val endOfLine = minOf(i + 9, end)
            val line = (i..endOfLine).joinToString(" ") { evaluate(it).padEnd(8) }
            println(line)
        }
    }
}