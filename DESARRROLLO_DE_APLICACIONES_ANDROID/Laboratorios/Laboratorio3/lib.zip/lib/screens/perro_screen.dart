import 'package:flutter/material.dart';
import '../services/api_service.dart';

class PerroScreen extends StatefulWidget {
  const PerroScreen({super.key});

  @override
  State<PerroScreen> createState() =>
      _PerroScreenState();
}

class _PerroScreenState
    extends State<PerroScreen> {

  final ApiService api = ApiService();

  final nombre = TextEditingController();
  final raza = TextEditingController();
  final edad = TextEditingController();

  List propietarios = [];
  String? propietarioId;

  @override
  void initState() {
    super.initState();
    cargarPropietarios();
  }

  Future<void> cargarPropietarios() async {
    propietarios =
    await api.obtenerPropietarios();

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Nuevo Perro"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(15),

        child: Column(
          children: [

            TextField(
              controller: nombre,
              decoration:
              const InputDecoration(
                labelText: "Nombre",
              ),
            ),

            TextField(
              controller: raza,
              decoration:
              const InputDecoration(
                labelText: "Raza",
              ),
            ),

            TextField(
              controller: edad,
              decoration:
              const InputDecoration(
                labelText: "Edad",
              ),
            ),

            DropdownButton<String>(
              value: propietarioId,
              hint: const Text("Seleccione propietario"),
              isExpanded: true,

              items: propietarios.map<DropdownMenuItem<String>>((p) {
                return DropdownMenuItem<String>(
                  value: p['_id'].toString(),
                  child: Text(p['nombre'].toString()),
                );
              }).toList(),

              onChanged: (String? value) {
                setState(() {
                  propietarioId = value;
                });
              },
            ),

            ElevatedButton(
              onPressed: () async {

                await api.crearPerro({
                  "nombre": nombre.text,
                  "raza": raza.text,
                  "edad":
                  int.parse(edad.text),
                  "propietario":
                  propietarioId
                });

                Navigator.pop(context);
              },
              child: const Text("Guardar"),
            )
          ],
        ),
      ),
    );
  }
}