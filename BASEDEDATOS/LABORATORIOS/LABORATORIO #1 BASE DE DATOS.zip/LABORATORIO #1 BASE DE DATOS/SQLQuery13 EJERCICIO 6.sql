/*EJERCICIO #6
Crear un stored procedure que clasifique el tipo de alquiler. 
Si la duraci�n del alquiler del auto dura 3 d�as o menos colocar "Alquiler corto". 
Si dura entre 4 y 7 colocar "Alquiler media duraci�n" y si dura m�s colocar "Alquiler larga duraci�n"*/

/*PASO 1
Primero, verifica si la tabla Rentals tiene una columna para almacenar el tipo de alquiler. 
Si no existe, puedes agregarla:*/

ALTER TABLE Rentals
ADD RentalType NVARCHAR(50) NULL;


/*PASO 2
A continuaci�n, se crea el procedimiento almacenado para clasificar el tipo de alquiler:*/

CREATE PROCEDURE ClassifyRentalType
AS
BEGIN
    -- Actualizar el tipo de alquiler en funci�n de la duraci�n
    UPDATE Rentals
    SET RentalType = CASE
        WHEN DATEDIFF(DAY, RentalDate, ISNULL(ReturnDate, GETDATE())) <= 3 THEN 'Alquiler corto'
        WHEN DATEDIFF(DAY, RentalDate, ISNULL(ReturnDate, GETDATE())) BETWEEN 4 AND 7 THEN 'Alquiler media duraci�n'
        ELSE 'Alquiler larga duraci�n'
    END;
END;


/*PASO 3
Para clasificar el tipo de alquiler en todos los registros existentes, simplemente ejecuta el procedimiento:*/

EXEC ClassifyRentalType;

/*PASO 4
Puedes verificar los resultados ejecutando una consulta como la siguiente:*/

SELECT RentalID, RentalDate, ReturnDate, RentalType
FROM Rentals;
