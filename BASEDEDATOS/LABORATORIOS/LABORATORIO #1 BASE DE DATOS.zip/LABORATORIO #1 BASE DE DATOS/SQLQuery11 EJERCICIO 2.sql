/*EJERCICIO #2
Crear un trigger que automaticamente cuanto es la ganancia luego de un recibir el pago.*/

CREATE TRIGGER trg_UpdateTotalIncome
ON Payments
AFTER INSERT
AS
BEGIN
    -- Actualizar el TotalIncome del auto asociado al pago
    UPDATE Cars
    SET TotalIncome = TotalIncome + i.Amount
    FROM Cars c
    INNER JOIN Rentals r ON c.CarID = r.CarID
    INNER JOIN INSERTED i ON r.RentalID = i.RentalID;
END;

/*Este trigger se usa automaticamente a la hora de hacer un recuento de la ganancias a la hora de recibir el pago
tambien dejo para como usar el trigger*/

-- Insertar un pago en la tabla Payments
INSERT INTO Payments (RentalID, PaymentDate, Amount, PaymentMethod)
VALUES (1, GETDATE(), 150.00, 'Credit Card');

-- Verificar que el TotalIncome se haya actualizado
SELECT * FROM Cars WHERE CarID = (SELECT CarID FROM Rentals WHERE RentalID = 1);

