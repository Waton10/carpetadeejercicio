import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../widgets/perro_card.dart';
import 'detalle_perro_screen.dart';
import 'perro_screen.dart';
import 'propietario_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() =>
      _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  final ApiService api = ApiService();

  List perros = [];

  @override
  void initState() {
    super.initState();
    cargarPerros();
  }

  Future<void> cargarPerros() async {
    perros = await api.obtenerPerros();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Pacientes"),
        actions: [
          IconButton(
            onPressed: cargarPerros,
            icon: const Icon(Icons.refresh),
          )
        ],
      ),

      drawer: Drawer(
        child: ListView(
          children: [

            const DrawerHeader(
              child: Text("Veterinaria"),
            ),

            ListTile(
              title: const Text(
                  "Registrar Propietario"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        PropietarioScreen(),
                  ),
                );
              },
            ),

            ListTile(
              title:
              const Text("Registrar Perro"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        PerroScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),

      body: ListView.builder(
        itemCount: perros.length,
        itemBuilder: (context, index) {

          return PerroCard(
            perro: perros[index],
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      DetallePerroScreen(
                        perro: perros[index],
                      ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}