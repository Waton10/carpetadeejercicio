// Interfaz común para todos los tipos de números
interface Number {
    val value: Int
    fun getType(): String
}

// Clase base abstracta para implementar funcionalidad común
abstract class AbstractNumber(override val value: Int) : Number {
    val divisors: List<Int> by lazy {
        (1..value).filter { value % it == 0 }
    }
}

// Clase para números primos
class PrimeNumber(value: Int) : AbstractNumber(value) {
    override fun getType() = "Prime"
}

// Clase para números pares
class EvenNumber(value: Int) : AbstractNumber(value) {
    override fun getType() = "Even"
}

// Clase para números impares
class OddNumber(value: Int) : AbstractNumber(value) {
    override fun getType() = "Odd"
}

// Clase principal que maneja la lógica del programa
class NumberClassifier {
    fun classify(n: Int): Triple<Int, Int, Int> {
        if (n <= 0) throw IllegalArgumentException("N must be a positive integer")

        var primeCount = 0
        var evenCount = 0
        var oddCount = 0

        for (i in 1..n) {
            when {
                isPrime(i) -> {
                    PrimeNumber(i)
                    primeCount++
                }
                i % 2 == 0 -> {
                    EvenNumber(i)
                    evenCount++
                }
                else -> {
                    OddNumber(i)
                    oddCount++
                }
            }
        }

        return Triple(primeCount, evenCount, oddCount)
    }

    private fun isPrime(num: Int): Boolean {
        if (num <= 1) return false
        for (i in 2..kotlin.math.sqrt(num.toDouble()).toInt()) {
            if (num % i == 0) return false
        }
        return true
    }
}

fun main() {
    val classifier = NumberClassifier()
    
    try {
        print("Enter a positive integer N: ")
        val n = readLine()?.toIntOrNull() ?: throw IllegalArgumentException("Invalid input")
        
        val (primeCount, evenCount, oddCount) = classifier.classify(n)
        
        println("Prime numbers count: $primeCount")
        println("Even numbers count: $evenCount")
        println("Odd numbers count: $oddCount")
    } catch (e: IllegalArgumentException) {
        println("Error: ${e.message}")
    }
}