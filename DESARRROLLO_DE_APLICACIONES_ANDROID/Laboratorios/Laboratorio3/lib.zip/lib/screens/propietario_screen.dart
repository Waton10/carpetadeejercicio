import 'package:flutter/material.dart';
import '../services/api_service.dart';

class PropietarioScreen extends StatelessWidget {
  PropietarioScreen({super.key});

  final nombre = TextEditingController();
  final telefono = TextEditingController();
  final direccion = TextEditingController();
  final correo = TextEditingController();

  final ApiService api = ApiService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Registrar Propietario"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: nombre,
                decoration: const InputDecoration(
                  labelText: "Nombre completo",
                ),
              ),

              const SizedBox(height: 10),

              TextField(
                controller: telefono,
                decoration: const InputDecoration(
                  labelText: "Teléfono",
                ),
              ),

              const SizedBox(height: 10),

              TextField(
                controller: direccion,
                decoration: const InputDecoration(
                  labelText: "Dirección",
                ),
              ),

              const SizedBox(height: 10),

              TextField(
                controller: correo,
                decoration: const InputDecoration(
                  labelText: "Correo electrónico",
                ),
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: () async {
                  try {
                    if (nombre.text.trim().isEmpty ||
                        telefono.text.trim().isEmpty ||
                        direccion.text.trim().isEmpty ||
                        correo.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            "Complete todos los campos",
                          ),
                        ),
                      );
                      return;
                    }

                    print("=== DATOS PROPIETARIO ===");
                    print("Nombre: ${nombre.text}");
                    print("Teléfono: ${telefono.text}");
                    print("Dirección: ${direccion.text}");
                    print("Correo: ${correo.text}");

                    await api.crearPropietario({
                      "nombre": nombre.text.trim(),
                      "telefono": telefono.text.trim(),
                      "direccion": direccion.text.trim(),
                      "correo": correo.text.trim(),
                    });

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          "Propietario guardado correctamente",
                        ),
                      ),
                    );

                    Navigator.pop(context);
                  } catch (e) {
                    print("ERROR: $e");

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          "Error al guardar: $e",
                        ),
                      ),
                    );
                  }
                },
                child: const Text("Guardar"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}