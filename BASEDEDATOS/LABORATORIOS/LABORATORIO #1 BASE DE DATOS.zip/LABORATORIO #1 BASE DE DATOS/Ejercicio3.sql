--Ejercicio3 Crear un stored procedure que calcule el monto total del auto rentado seg�n la cantidad--
--de d�as que el cliente lo tiene en su poder. Debe actualizar la fecha de retorno y el monto total.--

CREATE PROCEDURE CalcularMontoTotalRenta
    @RentalID INT,
    @FechaRetorno DATETIME
AS
BEGIN
    DECLARE @PrecioRenta DECIMAL(10, 2), 
            @FechaRenta DATETIME,
            @DiasRenta INT,
            @MontoTotal DECIMAL(10, 2);

    -- Obtener el precio de renta y la fecha de renta
    SELECT @PrecioRenta = c.RentalPrice, 
           @FechaRenta = r.RentalDate
    FROM Rentals r
    JOIN Cars c ON r.CarID = c.CarID
    WHERE r.RentalID = @RentalID;

    -- Calcular los d�as de renta
    SET @DiasRenta = DATEDIFF(DAY, @FechaRenta, @FechaRetorno);

    -- Calcular el monto total
    SET @MontoTotal = @DiasRenta * @PrecioRenta;

    -- Actualizar la fecha de retorno y el monto total
    UPDATE Rentals
    SET ReturnDate = @FechaRetorno, 
        TotalAmount = @MontoTotal
    WHERE RentalID = @RentalID;

    PRINT 'Monto total calculado y actualizado exitosamente.';
END;
GO