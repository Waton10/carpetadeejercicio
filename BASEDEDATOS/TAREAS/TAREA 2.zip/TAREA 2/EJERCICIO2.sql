/*EJERCICIO 2 :Cree una vista que retorne el listado de todos los clientes junto con la fecha y 
el monto total de la �ltima vez que se rent�. 
La consulta debe incluir a los clientes que nunca han alquilado un auto. 
La consulta debe retornar la siguiente informaci�n id del cliente, nombre del cliente, 
la �ltima fecha que se rent� y el monto total de la �ltima fecha que se rent�.*/

CREATE VIEW [dbo].[CustomerLastRental] AS
SELECT
    c.CustomerID,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    MAX(r.RentalDate) AS LastRentalDate,
    ISNULL(r.TotalAmount, 0) AS LastTotalAmount
FROM
    dbo.Customers c
LEFT JOIN
    (
        SELECT 
            CustomerID, 
            RentalDate, 
            TotalAmount,
            ROW_NUMBER() OVER(PARTITION BY CustomerID ORDER BY RentalDate DESC) AS RowNum
        FROM 
            dbo.Rentals
    ) r ON c.CustomerID = r.CustomerID AND r.RowNum = 1
GROUP BY
    c.CustomerID, c.FirstName, c.LastName, r.TotalAmount;

/*Con esta vista, obtendr�s una lista de todos los clientes con la fecha y el monto total de su �ltima renta. 
Si un cliente nunca ha alquilado un auto, se mostrar�n NULL en LastRentalDate y 0 en LastTotalAmount.*/