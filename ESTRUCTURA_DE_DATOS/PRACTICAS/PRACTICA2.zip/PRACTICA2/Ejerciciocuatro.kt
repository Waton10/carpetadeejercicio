fun main() {
    val numeros = mutableListOf<Int>()
    
    for (i in 1..4) {
        while (true) {
            try {
                print("Ingrese el número $i: ")
                val input = readLine()
                val numero = input?.toInt() ?: throw NumberFormatException("Entrada vacía")
                
                numeros.add(numero)
                break
            } catch (e: NumberFormatException) {
                println("Error: Entrada no válida. Por favor, ingrese un número entero.")
            }
        }
    }
    
    val numeroMayor = numeros.maxOrNull()
    println("Los números ingresados son: ${numeros.joinToString(", ")}")
    println("El número mayor es: $numeroMayor")
}