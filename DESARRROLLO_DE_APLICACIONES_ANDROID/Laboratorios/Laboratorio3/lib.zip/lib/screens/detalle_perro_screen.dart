import 'package:flutter/material.dart';
import '../services/api_service.dart';

class DetallePerroScreen extends StatefulWidget {

  final Map perro;

  const DetallePerroScreen({
    super.key,
    required this.perro,
  });

  @override
  State<DetallePerroScreen> createState() =>
      _DetallePerroScreenState();
}

class _DetallePerroScreenState
    extends State<DetallePerroScreen> {

  final ApiService api = ApiService();

  List historial = [];

  @override
  void initState() {
    super.initState();
    cargarHistorial();
  }

  Future<void> cargarHistorial() async {

    historial = await api.obtenerHistorial(
      widget.perro['_id'],
    );

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {

    final propietario =
    widget.perro['propietario'];

    return Scaffold(

      appBar: AppBar(
        title: Text(widget.perro['nombre']),
      ),

      floatingActionButton:
      FloatingActionButton(
        child: const Icon(Icons.add),

        onPressed: () async {

          final peso =
          TextEditingController();

          final diagnostico =
          TextEditingController();

          final tratamiento =
          TextEditingController();

          final observaciones =
          TextEditingController();

          showDialog(
            context: context,

            builder: (_) => AlertDialog(
              title:
              const Text("Consulta"),

              content: SingleChildScrollView(
                child: Column(
                  children: [

                    TextField(
                      controller: peso,
                      decoration:
                      const InputDecoration(
                        labelText: "Peso",
                      ),
                    ),

                    TextField(
                      controller:
                      diagnostico,
                      decoration:
                      const InputDecoration(
                        labelText:
                        "Diagnóstico",
                      ),
                    ),

                    TextField(
                      controller:
                      tratamiento,
                      decoration:
                      const InputDecoration(
                        labelText:
                        "Tratamiento",
                      ),
                    ),

                    TextField(
                      controller:
                      observaciones,
                      decoration:
                      const InputDecoration(
                        labelText:
                        "Observaciones",
                      ),
                    ),
                  ],
                ),
              ),

              actions: [
                TextButton(
                  onPressed: () async {

                    await api
                        .crearHistorial({
                      "perro":
                      widget.perro['_id'],
                      "peso":
                      double.parse(
                          peso.text),
                      "diagnostico":
                      diagnostico.text,
                      "tratamiento":
                      tratamiento.text,
                      "observaciones":
                      observaciones.text
                    });

                    Navigator.pop(
                        context);

                    cargarHistorial();
                  },
                  child:
                  const Text("Guardar"),
                )
              ],
            ),
          );
        },
      ),

      body: Padding(
        padding: const EdgeInsets.all(15),

        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,

          children: [

            Text(
              "Raza: ${widget.perro['raza']}",
            ),

            Text(
              "Edad: ${widget.perro['edad']}",
            ),

            const SizedBox(height: 10),

            Text(
              "Propietario: ${propietario['nombre']}",
            ),

            Text(
              "Teléfono: ${propietario['telefono']}",
            ),

            const Divider(),

            const Text(
              "Historial Clínico",
              style: TextStyle(
                fontSize: 18,
                fontWeight:
                FontWeight.bold,
              ),
            ),

            Expanded(
              child: ListView.builder(
                itemCount: historial.length,

                itemBuilder:
                    (context, index) {

                  final item =
                  historial[index];

                  return Card(
                    child: ListTile(
                      title: Text(
                        item['diagnostico'],
                      ),
                      subtitle: Text(
                        "Peso: ${item['peso']}\n"
                            "Tratamiento: ${item['tratamiento']}\n"
                            "Obs: ${item['observaciones']}",
                      ),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}