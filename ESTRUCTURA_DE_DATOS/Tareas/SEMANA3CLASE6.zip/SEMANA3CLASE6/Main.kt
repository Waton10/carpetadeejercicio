// Interfaz común para todos los tipos de números
interface IBaseNumber {
    val value: Int
    fun printValue()
}

// Clase para números primos
class PrimeNumber(override val value: Int) : IBaseNumber {
    override fun printValue() {
        println("Prime Number: $value")
    }
}

// Clase para números impares
class OddNumber(override val value: Int) : IBaseNumber {
    val divisors: List<Int> = findDivisors(value)

    override fun printValue() {
        println("Odd Number: $value, Divisors: $divisors")
    }

    private fun findDivisors(number: Int): List<Int> {
        return (1..number).filter { number % it == 0 }
    }
}

// Clase para números pares
class EvenNumber(override val value: Int) : IBaseNumber {
    val divisors: List<Int> = findDivisors(value)

    override fun printValue() {
        println("Even Number: $value, Divisors: $divisors")
    }

    private fun findDivisors(number: Int): List<Int> {
        return (1..number).filter { number % it == 0 }
    }
}

// Clase para procesar el rango de números y clasificarlos
class PrimeNumberProcessor(val range: IntRange) {

    data class EvaluationResult(
        val primes: MutableList<PrimeNumber> = mutableListOf(),
        val odds: MutableList<OddNumber> = mutableListOf(),
        val evens: MutableList<EvenNumber> = mutableListOf()
    )

    fun evaluateNumbers(): EvaluationResult {
        val result = EvaluationResult()

        for (number in range) {
            when {
                isPrime(number) -> result.primes.add(PrimeNumber(number))
                number % 2 == 0 -> result.evens.add(EvenNumber(number))
                else -> result.odds.add(OddNumber(number))
            }
        }

        return result
    }

    private fun isPrime(number: Int): Boolean {
        if (number < 2) return false
        for (i in 2..Math.sqrt(number.toDouble()).toInt()) {
            if (number % i == 0) return false
        }
        return true
    }
}

// Función principal para probar el código
fun main() {
    val processor = PrimeNumberProcessor(1..20)
    val result = processor.evaluateNumbers()

    // Imprimir los números clasificados
    result.primes.forEach { it.printValue() }
    result.odds.forEach { it.printValue() }
    result.evens.forEach { it.printValue() }
}
