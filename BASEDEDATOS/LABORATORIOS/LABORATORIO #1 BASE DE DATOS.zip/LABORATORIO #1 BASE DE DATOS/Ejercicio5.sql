--EJERCICIO 5 Determinar el status de un cliente, si el cliente ha gastado--
--menos de $500 debe imprimir "cliente nuevo", si el cliente ha gastado entre--
--$500 y $2500 imprimir "cliente frecuente" y si ha gastado m�s de $2500 imprimir--
--"cliente VIP". La consulta debe mostrar las consulta nombre del cliente, id del cliente, total gastado y el status del cliente.--
SELECT 
    c.CustomerID,
    CONCAT(c.FirstName, ' ', c.LastName) AS NombreCliente,
    SUM(r.TotalAmount) AS GastoTotal,
    CASE 
        WHEN SUM(r.TotalAmount) < 500 THEN 'Cliente Nuevo'
        WHEN SUM(r.TotalAmount) BETWEEN 500 AND 2500 THEN 'Cliente Frecuente'
        ELSE 'Cliente VIP'
    END AS Estatus
FROM Rentals r
JOIN Customers c ON r.CustomerID = c.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName;
GO
