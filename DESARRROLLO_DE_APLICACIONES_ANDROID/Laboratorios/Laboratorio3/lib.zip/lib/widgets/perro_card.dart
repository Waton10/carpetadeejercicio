import 'package:flutter/material.dart';

class PerroCard extends StatelessWidget {

  final Map perro;
  final VoidCallback onTap;

  const PerroCard({
    super.key,
    required this.perro,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {

    return Card(
      child: ListTile(
        leading: const Icon(
          Icons.pets,
          size: 40,
        ),
        title: Text(perro['nombre']),
        subtitle: Text(perro['raza']),
        trailing: const Icon(Icons.arrow_forward),
        onTap: onTap,
      ),
    );
  }
}