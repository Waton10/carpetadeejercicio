import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {

  // CAMBIA ESTA IP POR LA DE TU COMPUTADORA
  static const String baseUrl =
      "http://10.15.0.118:3000/api";

  // ================= PERROS =================

  Future<List<dynamic>> obtenerPerros() async {

    final response =
    await http.get(Uri.parse('$baseUrl/perros'));

    print("GET PERROS: ${response.statusCode}");
    print(response.body);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    throw Exception("Error al obtener perros");
  }

  Future<void> crearPerro(
      Map<String, dynamic> perro) async {

    final response = await http.post(
      Uri.parse('$baseUrl/perros'),
      headers: {
        'Content-Type': 'application/json'
      },
      body: jsonEncode(perro),
    );

    print("POST PERRO STATUS: ${response.statusCode}");
    print("POST PERRO BODY: ${response.body}");

    if (response.statusCode != 200 &&
        response.statusCode != 201) {
      throw Exception("Error al guardar perro");
    }
  }

  // ================= PROPIETARIOS =================

  Future<List<dynamic>> obtenerPropietarios() async {

    final response =
    await http.get(Uri.parse('$baseUrl/propietarios'));

    print("GET PROPIETARIOS: ${response.statusCode}");

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    throw Exception("Error al obtener propietarios");
  }

  Future<void> crearPropietario(
      Map<String, dynamic> propietario) async {

    final response = await http.post(
      Uri.parse('$baseUrl/propietarios'),
      headers: {
        'Content-Type': 'application/json'
      },
      body: jsonEncode(propietario),
    );

    print("STATUS: ${response.statusCode}");
    print("BODY: ${response.body}");

    if (response.statusCode != 200 &&
        response.statusCode != 201) {
      throw Exception(response.body);
    }

    print("POST PROPIETARIO STATUS: ${response.statusCode}");
    print("POST PROPIETARIO BODY: ${response.body}");

    if (response.statusCode != 200 &&
        response.statusCode != 201) {
      throw Exception("Error al guardar propietario");
    }
  }

  // ================= HISTORIAL =================

  Future<List<dynamic>> obtenerHistorial(
      String perroId) async {

    final response = await http.get(
      Uri.parse('$baseUrl/historial/$perroId'),
    );

    print("GET HISTORIAL: ${response.statusCode}");

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    throw Exception("Error al obtener historial");
  }

  Future<void> crearHistorial(
      Map<String, dynamic> historial) async {

    final response = await http.post(
      Uri.parse('$baseUrl/historial'),
      headers: {
        'Content-Type': 'application/json'
      },
      body: jsonEncode(historial),
    );

    print("POST HISTORIAL STATUS: ${response.statusCode}");
    print("POST HISTORIAL BODY: ${response.body}");

    if (response.statusCode != 200 &&
        response.statusCode != 201) {
      throw Exception("Error al guardar historial");
    }
  }
}