--EJERCICIO 1 Crear un trigger que prevenga rentar un auto que ya est� rentado.--
--El trigger debe verificar las fechas en las que fue rentado y la fecha de retorno--
--para prevenir que se rente ese mismo auto nuevamente.--
CREATE TRIGGER trg_PrevenirDobleRenta
ON Rentals
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @CarID INT, @FechaRenta DATETIME, @FechaRetorno DATETIME;

    SELECT @CarID = inserted.CarID, 
           @FechaRenta = inserted.RentalDate, 
           @FechaRetorno = inserted.ReturnDate
    FROM inserted;

    IF EXISTS (
        SELECT 1 
        FROM Rentals 
        WHERE CarID = @CarID 
          AND (
               (@FechaRenta BETWEEN RentalDate AND ReturnDate) 
               OR 
               (@FechaRetorno BETWEEN RentalDate AND ReturnDate)
              )
    )
    BEGIN
        RAISERROR('El auto ya est� rentado durante el periodo seleccionado.', 16, 1);
        ROLLBACK TRANSACTION;
    END
    ELSE
    BEGIN
        INSERT INTO Rentals (CustomerID, CarID, RentalDate, ReturnDate, TotalAmount)
        SELECT CustomerID, CarID, RentalDate, ReturnDate, TotalAmount 
        FROM inserted;
    END
END;
GO