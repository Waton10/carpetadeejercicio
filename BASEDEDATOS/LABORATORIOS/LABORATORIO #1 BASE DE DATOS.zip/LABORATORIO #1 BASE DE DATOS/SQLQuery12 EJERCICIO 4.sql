/*EJERCICIO #4
Crear una consulta para recuperar rentas vencidos seg�n la fecha actual. Debe mostrar el nombre del cliente, el autom�v�l, 
la fecha de retorno, el modelo del autom�v�l y la cantidad de d�as de atraso. 
Si no existen clientes atrasados debe mostrar un mensaje como el siguiente: "No hay rentas atrasadas."*/

/*Esta es la consulta para ver la vrentas vencidas*/

SELECT 
    c.FirstName + ' ' + c.LastName AS CustomerName,
    ca.Make + ' ' + ca.Model AS CarModel,
    r.ReturnDate,
    DATEDIFF(DAY, r.ReturnDate, GETDATE()) AS DaysLate
FROM 
    Rentals r
JOIN 
    Customers c ON r.CustomerID = c.CustomerID
JOIN 
    Cars ca ON r.CarID = ca.CarID
WHERE 
    r.ReturnDate < GETDATE()
    AND r.ReturnDate IS NOT NULL;

/*Para mostrar un mensaje si no hay rentas atrasadas, 
puedes usar un bloque IF EXISTS para verificar si la consulta retorna resultados y,
en caso contrario, mostrar un mensaje:*/

IF EXISTS (
    SELECT 1 
    FROM Rentals 
    WHERE ReturnDate < GETDATE()
    AND ReturnDate IS NOT NULL
)
BEGIN
    SELECT 
        c.FirstName + ' ' + c.LastName AS CustomerName,
        ca.Make + ' ' + ca.Model AS CarModel,
        r.ReturnDate,
        DATEDIFF(DAY, r.ReturnDate, GETDATE()) AS DaysLate
    FROM 
        Rentals r
    JOIN 
        Customers c ON r.CustomerID = c.CustomerID
    JOIN 
        Cars ca ON r.CarID = ca.CarID
    WHERE 
        r.ReturnDate < GETDATE()
        AND r.ReturnDate IS NOT NULL;
END
ELSE
BEGIN
    PRINT 'No hay rentas atrasadas.';
END
