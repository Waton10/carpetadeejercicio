/*EJERCICIO 1 : Cree una vista que retorne la informaci�n de cada auto junto con el per�odo de alquiler m�s amplio que ha tenido.
Hay que retornar adem�s aquellos auto que nunca se han rentado.
La consulta debe retornar la siguiente informaci�n el id del auto, 
el modelo del auto, la marca del auto, el a�o del auto y el per�odo de alquiler m�s largo que ha tenido.*/

CREATE VIEW [dbo].[CarLongestRentalPeriod] AS
SELECT
    c.CarID,
    c.Make,
    c.Model,
    c.Year,
    ISNULL(DATEDIFF(day, r.RentalDate, r.ReturnDate), 0) AS LongestRentalPeriod
FROM
    dbo.Cars c
LEFT JOIN
    (
        SELECT
            CarID,
            MAX(DATEDIFF(day, RentalDate, ReturnDate)) AS LongestPeriod
        FROM
            dbo.Rentals
        GROUP BY
            CarID
    ) AS rental_info ON c.CarID = rental_info.CarID
LEFT JOIN
    dbo.Rentals r ON c.CarID = r.CarID 
    AND DATEDIFF(day, r.RentalDate, r.ReturnDate) = rental_info.LongestPeriod;

/*el c�digo crea una vista que muestra todos los autos con el per�odo de alquiler m�s largo que han tenido.
Para los autos que nunca se han rentado, se muestra un per�odo de 0.*/