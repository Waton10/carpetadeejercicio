/*EJERCICIO 3:Cree una vista que muestre el listado de todos los clientes junto con los autos que han alquilado con m�s frecuencia. 
Hay que incluir los clientes que no han alquilado autos. 
La consulta debe mostrar la siguiente informaci�n id del cliente, nombre del cliente, 
id del auto, marca, modelo, a�o del auto y la cantidad total de veces que se ha alquilado el auto. */

CREATE VIEW [dbo].[CustomerMostRentedCars] AS
SELECT
    c.CustomerID,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    car.CarID,
    car.Make,
    car.Model,
    car.Year,
    ISNULL(rental_info.RentalCount, 0) AS TotalRentals
FROM
    dbo.Customers c
LEFT JOIN
    (
        SELECT 
            r.CustomerID, 
            r.CarID,
            COUNT(*) AS RentalCount,
            ROW_NUMBER() OVER(PARTITION BY r.CustomerID ORDER BY COUNT(*) DESC) AS RowNum
        FROM 
            dbo.Rentals r
        GROUP BY 
            r.CustomerID, r.CarID
    ) rental_info ON c.CustomerID = rental_info.CustomerID AND rental_info.RowNum = 1
LEFT JOIN
    dbo.Cars car ON rental_info.CarID = car.CarID;

/*Esta vista, CustomerMostRentedCars,
te proporciona una lista de todos los clientes junto con el auto que han alquilado con mayor frecuencia. 
Para los clientes que nunca han alquilado un auto, el campo TotalRentals ser� 0, y los campos relacionados con el auto ser�n NULL.*/