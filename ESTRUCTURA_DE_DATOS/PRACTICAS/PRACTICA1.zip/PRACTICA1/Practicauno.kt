fun main() {
    println("Ingrese el primer numero")
    val numeroUno = readline().toDouble()

    println("Ingrese el primer numero")
    val numeroDos = readline().toDouble()

    println("Ingrese la operacion(+, -, *, /):")
    val operacion = readline()

    calculate(numeroUno, numeroDos, operacion)
}

fun calculate(numeroUno: Double, numeroDos: Double, operacion: String){
    if (numeroUno == null || numeroDos == null || operacion == null){
        println("Error: Ingrese numeros validos y una operacion valida")
        return
    }

    val resultados == when (operacion){
        "+" -> numeroUno + numeroDos
        "-" -> numeroUno - numeroDos
        "*" -> numeroUno * numeroDos
        "/" -> numeroUno / numeroDos
        else -> {
            println("Error: Operacion no valida.")
            return
        }
    }

    println("Resultado de la operacion $operacion $numeroDos = Resultado")
}